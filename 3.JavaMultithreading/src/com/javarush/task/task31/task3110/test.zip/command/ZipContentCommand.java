package com.javarush.task.task31.task3110.command;

public class ZipContentCommand extends ZipCommand {
    @Override
    public void execute() throws Exception {

    }
}
