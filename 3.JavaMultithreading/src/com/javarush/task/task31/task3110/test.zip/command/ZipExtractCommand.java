package com.javarush.task.task31.task3110.command;

public class ZipExtractCommand extends ZipCommand {
    @Override
    public void execute() throws Exception {

    }
}
