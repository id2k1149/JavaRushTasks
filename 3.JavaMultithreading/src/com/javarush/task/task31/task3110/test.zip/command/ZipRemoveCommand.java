package com.javarush.task.task31.task3110.command;

public class ZipRemoveCommand extends ZipCommand {
    @Override
    public void execute() throws Exception {

    }
}
